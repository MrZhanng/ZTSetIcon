//
//  ViewController.m
//  ZTSetIcon
//
//  Created by Mac on 2017/8/23.
//  Copyright © 2017年 Mac. All rights reserved.
//

#import "ViewController.h"
#import "ImgClipViewController.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,ClipViewControllerDelegate>
{
    ClipType clipType;//裁剪类型
}
@property (weak, nonatomic) IBOutlet UIImageView *iconV;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)setRouIBtn:(id)sender {
    clipType = CIRCULARCLIP;
    [self Alert];
}
- (IBAction)setSquareIbtn:(id)sender {
    clipType = SQUARECLIP;
    [self Alert];
}

-(void)Alert{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString* Alerttitle = @"更改头像";
        NSArray* alertArr = [NSArray arrayWithObjects:@"拍照",@"相册", nil];
        UIAlertController *alertDialog = [UIAlertController alertControllerWithTitle:Alerttitle message:nil preferredStyle:UIAlertControllerStyleActionSheet];
        NSMutableAttributedString *hogan = [[NSMutableAttributedString alloc] initWithString:Alerttitle];
        [hogan addAttribute:NSFontAttributeName
                      value:[UIFont boldSystemFontOfSize:20]
                      range:NSMakeRange(0, Alerttitle.length)];
        [alertDialog setValue:hogan forKey:@"attributedTitle"];
        
        UIAlertAction *laterAction = [UIAlertAction actionWithTitle:alertArr[0] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self useCamera];
            
        }];
        UIAlertAction *laterAction1 = [UIAlertAction actionWithTitle:alertArr[1] style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self usePhoto];
            
        }];
        
        [alertDialog addAction:laterAction];
        [alertDialog addAction:laterAction1];
        
        UIAlertAction *CancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        }];
        [alertDialog addAction:CancelAction];
        [self presentViewController:alertDialog animated:YES completion:nil];
    });
}

-(void)usePhoto{
    UIImagePickerController * picker = [[UIImagePickerController alloc]init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

-(void)useCamera{
    
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        UIImagePickerController * picker = [[UIImagePickerController alloc]init];
        picker.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker.delegate = self;
        [self presentViewController:picker animated:YES completion:nil];
        //允许编辑
        //        imagePicker.allowsEditing=true;
        
    }else{
        NSLog(@"模拟器不支持拍照功能");
    }
    
}

#pragma mark - imagePickerControllerDelegate
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    UIImage * image = info[@"UIImagePickerControllerOriginalImage"];
    
    ImgClipViewController * clipView = [[ImgClipViewController alloc]initWithImage:image];
    clipView.delegate = self;
    clipView.clipType = clipType; //支持圆形:CIRCULARCLIP 方形裁剪:SQUARECLIP   默认:圆形裁剪
    
    //    clipView.scaleRation = 5;// 图片缩放的最大倍数 默认为10
    [picker pushViewController:clipView animated:YES];
    
}

#pragma mark - ClipViewControllerDelegate
-(void)ClipViewController:(ImgClipViewController *)clipViewController FinishClipImage:(UIImage *)editImage
{
    
    [clipViewController dismissViewControllerAnimated:YES completion:^{
        
        self.iconV.image = editImage;
        
//        NSData * imageData = UIImagePNGRepresentation(editImage);
        
    }];;
}





@end
